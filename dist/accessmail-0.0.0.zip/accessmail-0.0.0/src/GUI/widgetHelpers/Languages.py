__author__ = 'grafgustav'

# this file contains the language files to display buttons and labels in alternative languages
# for now I've just changed all labels to german language