__author__ = 'grafgustav'
from kivy.lang import Builder
from kivy.uix.screenmanager import Screen


Builder.load_file('GUI/menuLayout.kv')


class MenuLayout(Screen):
    pass