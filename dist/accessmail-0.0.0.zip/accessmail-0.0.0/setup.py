from distutils.core import setup

setup(
    name='accessmail',
    version='',
    packages=['src', 'src.GUI', 'src.GUI.widgetHelpers', 'src.Service', 'src.Controller'],
    url='',
    license='',
    author='Vyrtan',
    author_email='',
    description=''
)
